var INPUT = document.querySelector('input');
var GAUGE = document.querySelector('.gauge');
var LABEL = GAUGE.querySelector('.gauge__label');

var UPDATE = function() {
  LABEL.innerText = INPUT.value;
  GAUGE.style.setProperty('--progress', INPUT.value / 100);
};

INPUT.addEventListener('input', UPDATE);

UPDATE();
