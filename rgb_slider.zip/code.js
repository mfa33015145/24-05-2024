import * as ko from "https://cdn.skypack.dev/knockout@3.5.1";

class Colors{
	constructor(){
		this.r = ko.observable(0);
		this.g = ko.observable(0);
		this.b = ko.observable(0);
		this.copied = ko.observable(false);
		this.timeout = false;
		
		this.computedValue = ko.pureComputed(()=>{
			return `rgb(${this.r()},${this.g()},${this.b()})`;
		})
	}
	copy(){
		if(this.timeout) clearTimeout(this.timeout);
		navigator.clipboard.writeText(this.computedValue());
		this.copied(true);
		this.timeout = setTimeout(()=>this.copied(false),1000);
	}
}
const colors = new Colors();
ko.applyBindings(colors)