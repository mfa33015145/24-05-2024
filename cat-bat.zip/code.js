var tid = setTimeout(change, 2000);

function change() {
  
  $("#frame").toggleClass("cat");
  $("#frame").toggleClass("bat");
  
  tid = setTimeout(change, 5000); 
  
};